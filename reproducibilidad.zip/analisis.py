"""Clasificación reproducible de aspiraciones declaradas; no recomendación validada."""
from pathlib import Path
from collections import Counter
import re, json, hashlib, sys, platform, io, contextlib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
SEED = 2026
SOURCE = ROOT / 'datos' / 'Career Dataset.xlsx'
EXPECTED = 'df029f3b4008b55c036d34502800a27c86e59993c74d0510b3bb788e26d901e5'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
raw = pd.read_excel(SOURCE)
normalize = lambda value: re.sub(r'\s+', ' ', str(value).lower()).strip()
data = raw.dropna(subset=['Skill', 'Career']).copy()
data['text'] = data.Skill.map(normalize)
data['label'] = data.Career.astype(str).str.strip()
data = data[(data.text != '') & (data.label != '')]
before = len(data)
data = data.drop_duplicates(['text', 'label']).reset_index(drop=True)
labels = sorted(data.label.unique())
to_id = {v: i for i, v in enumerate(labels)}
y = data.label.map(to_id).to_numpy()

# Assign whole normalized-text groups to folds, with class balancing.
# Labels only determine stratification; vocabulary is fitted inside each training fold.
rng = np.random.default_rng(SEED)
groups = list(data.groupby('text', sort=True).indices.values())
rng.shuffle(groups)
groups.sort(key=len, reverse=True)
fold_counts = np.zeros((5, len(labels)), dtype=int)
fold_sizes = np.zeros(5, dtype=int)
fold = np.full(len(data), -1, dtype=int)
for idx in groups:
    counts = np.bincount(y[idx], minlength=len(labels))
    candidates = list(rng.permutation(5))
    chosen = min(candidates, key=lambda k: (int(np.dot(fold_counts[k], counts)), int(fold_sizes[k])))
    fold[idx] = chosen
    fold_counts[chosen] += counts
    fold_sizes[chosen] += len(idx)
data['fold'] = fold + 1
data.to_csv(ROOT / 'datos' / 'datos_depurados_y_particiones.csv', index=False, encoding='utf-8-sig')

def tokens(text):
    return re.findall(r'(?u)\b\w\w+\b', text)

def matrix(texts, vocabulary):
    result = np.zeros((len(texts), len(vocabulary)), dtype=np.float64)
    for row, text in enumerate(texts):
        for word, count in Counter(tokens(text)).items():
            column = vocabulary.get(word)
            if column is not None:
                result[row, column] = count
    return result

def scores(actual, predicted):
    cm = np.zeros((len(labels), len(labels)), dtype=int)
    np.add.at(cm, (actual, predicted), 1)
    tp = np.diag(cm).astype(float)
    prec = np.divide(tp, cm.sum(0), out=np.zeros_like(tp), where=cm.sum(0) != 0)
    recall = np.divide(tp, cm.sum(1), out=np.zeros_like(tp), where=cm.sum(1) != 0)
    f1 = np.divide(2*prec*recall, prec+recall, out=np.zeros_like(tp), where=(prec+recall) != 0)
    return {'accuracy': float(tp.sum()/cm.sum()), 'precision_macro': float(prec.mean()),
            'recall_macro': float(recall.mean()), 'f1_macro': float(f1.mean())}, cm

records, predictions = [], []
oof_nb = np.full(len(data), -1, dtype=int)
oof_base = np.full(len(data), -1, dtype=int)
example = None
for k in range(5):
    train, test = np.where(fold != k)[0], np.where(fold == k)[0]
    assert set(data.text.iloc[train]).isdisjoint(set(data.text.iloc[test]))
    assert len(set(y[train])) == len(labels) and len(set(y[test])) == len(labels)
    vocab = {word: i for i, word in enumerate(sorted({w for text in data.text.iloc[train] for w in tokens(text)}))}
    Xtr = matrix(data.text.iloc[train].tolist(), vocab)
    Xte = matrix(data.text.iloc[test].tolist(), vocab)
    nclass = np.bincount(y[train], minlength=len(labels))
    term_counts = np.vstack([Xtr[y[train] == c].sum(0) for c in range(len(labels))])
    log_word = np.log((term_counts + 1) / (term_counts.sum(1, keepdims=True) + len(vocab)))
    log_prior = np.log(nclass/nclass.sum())
    posterior = Xte @ log_word.T + log_prior
    pred = posterior.argmax(1)
    base = np.full(len(test), nclass.argmax(), dtype=int)
    oof_nb[test], oof_base[test] = pred, base
    for name, output in [('Mayoritaria', base), ('Naive Bayes multinomial', pred)]:
        metrics, _ = scores(y[test], output)
        records.append({'fold': k+1, 'modelo': name, 'n_train': len(train), 'n_test': len(test),
                        'vocabulary': len(vocab), **metrics})
    # First held-out record, selected by order rather than model success.
    if k == 0:
        j = 0
        order = np.argsort(-posterior[j], kind='stable')
        first, second = order[:2]
        word_weights = Xte[j] * (log_word[first] - log_word[second])
        inverse = {index: word for word, index in vocab.items()}
        present = np.where(Xte[j] > 0)[0]
        positive = sorted(present, key=lambda i: -word_weights[i])[:5]
        negative = sorted(present, key=lambda i: word_weights[i])[:5]
        example = {'row_cleaned_0_based': int(test[j]), 'fold': 1,
                   'text': data.text.iloc[test[j]], 'actual': labels[y[test[j]]],
                   'predicted': labels[first], 'runner_up': labels[second],
                   'prior_difference': float(log_prior[first]-log_prior[second]),
                   'score_difference': float(posterior[j, first]-posterior[j, second]),
                   'contributions_sum': float(word_weights.sum()),
                   'positive': [[inverse[i], float(word_weights[i])] for i in positive],
                   'negative': [[inverse[i], float(word_weights[i])] for i in negative]}
        assert np.isclose(example['score_difference'], example['prior_difference']+example['contributions_sum'])

metrics_frame = pd.DataFrame(records)
metrics_frame.to_csv(ROOT / 'metricas_por_particion.csv', index=False, encoding='utf-8-sig')
summary = {}
for name in metrics_frame.modelo.unique():
    part = metrics_frame[metrics_frame.modelo == name]
    summary[name] = {metric: {'mean': float(part[metric].mean()), 'std': float(part[metric].std(ddof=1))}
                     for metric in ('accuracy', 'precision_macro', 'recall_macro', 'f1_macro')}
global_scores, cm = scores(y, oof_nb)
base_scores, _ = scores(y, oof_base)
assert (oof_nb >= 0).all() and (oof_base >= 0).all()
data['prediction_nb'] = [labels[i] for i in oof_nb]
data['prediction_baseline'] = [labels[i] for i in oof_base]
data.to_csv(ROOT / 'predicciones_fuera_de_muestra.csv', index=False, encoding='utf-8-sig')
result = {'seed': SEED, 'raw_n': len(raw), 'removed_missing_or_empty': len(raw)-before,
          'removed_duplicate_pairs': before-len(data), 'clean_n': len(data),
          'unique_text_groups': data.text.nunique(),
          'conflicting_text_groups': int((data.groupby('text').label.nunique()>1).sum()),
          'classes_raw': raw.Career.str.strip().value_counts().to_dict(),
          'classes_clean': data.label.value_counts().to_dict(), 'labels': labels,
          'fold_sizes': fold_sizes.tolist(), 'summary': summary,
          'oof_nb': global_scores, 'oof_baseline': base_scores, 'confusion_matrix': cm.tolist(),
          'example': example, 'sha256_source': EXPECTED,
          'versions': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__}}
(ROOT / 'resultados.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ['example','confusion_matrix']}, ensure_ascii=False, indent=2))
