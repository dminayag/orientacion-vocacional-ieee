# Reproducción del experimento

Este paquete acompaña Plantilla_Short_Paper_Final.docx. Contiene un experimento ejecutado con datos públicos, sus resultados y el código para reproducirlo. No contiene los perfiles artificiales usados en una etapa anterior de la tarea.

## Fuente y licencia

Sakir Hossain Faruque y sharun akter khushbu, Student Career Dataset, Mendeley Data, versión 2, 17 de octubre de 2024. DOI https://doi.org/10.17632/4spj4mbpjr.2. Fuente https://data.mendeley.com/datasets/4spj4mbpjr/2. Licencia Creative Commons Attribution 4.0 https://creativecommons.org/licenses/by/4.0/.

Los depositantes describen datos de encuestas a universitarios de computación e ingeniería de software de Bangladesh. El archivo original Career Dataset.xlsx se preserva sin modificaciones y coincide con el SHA-256 del repositorio. Los datos depurados, las particiones y las predicciones son transformaciones producidas para este análisis. Su inclusión no implica respaldo de los depositantes a este artículo.

## Archivos

- Short_Paper_experimento_ejecutado.ipynb: notebook con una celda computacional ejecutada localmente y salidas guardadas. Puede cargarse en Colab mediante Archivo → Subir notebook. No se ha publicado ni ejecutado en Colab.
- analisis.py: implementación del mismo análisis para ejecución desde una terminal.
- datos/Career Dataset.xlsx: archivo público original.
- datos/metadata_mendeley.json: metadatos consultados del repositorio.
- datos/datos_depurados_y_particiones.csv: pares únicos normalizados y asignación a particiones.
- predicciones_fuera_de_muestra.csv: etiquetas reales declaradas y predicciones de ambos modelos.
- metricas_por_particion.csv: métricas por modelo y partición.
- resultados.json: resumen, matriz de confusión y ejemplo de contribuciones.
- figuras/: figuras generadas a partir del flujo ejecutado y sus métricas, en PNG y PDF vectorial.

## Entorno y ejecución

Entorno verificado: Python 3.12.14, NumPy 2.3.5, pandas 3.0.1 y openpyxl 3.1.5. Semilla 2026. La implementación de Naive Bayes usa NumPy directamente, sin scikit-learn.

Para ejecutar el script, mantener analisis.py junto con la carpeta datos y usar `python analisis.py`. Para ejecutar el notebook, cargarlo en Jupyter o Colab y ejecutar la celda. Si no existe el archivo original en la carpeta datos, el notebook lo descarga de Mendeley y comprueba su hash antes del análisis. Los números de versión y la instalación sugerida para Colab están documentados en el notebook. Los resultados locales guardados no acreditan ejecución en otra plataforma.

La depuración normaliza texto a minúsculas y espacios simples y elimina pares texto–etiqueta duplicados. Se conservan etiquetas discrepantes y se asignan a una misma partición los textos exactamente iguales. La selección de vocabulario se repite usando solo entrenamiento. No hay búsqueda de hiperparámetros ni selección del caso explicativo por desempeño.

## Alcance

Se predicen aspiraciones profesionales autodeclaradas. Las etiquetas no son una prueba de aptitud ni un criterio de carrera correcta. El dataset no proviene de Andahuaylas y el análisis no evalúa un chatbot, comprensión de explicaciones o efectos en decisiones. El control por texto exacto no evita todos los posibles textos similares ni garantiza independencia por participante. La ausencia de IDs personales impide esa comprobación.

Verificaciones realizadas: identidad del archivo público por SHA-256, ausencia de solapamiento textual entre entrenamiento y evaluación, presencia de las seis clases en cada partición, predicciones fuera de muestra para todos los pares, reconstrucción exacta de una explicación y coincidencia de la matriz de confusión recalculada desde el CSV con la salida del experimento.
