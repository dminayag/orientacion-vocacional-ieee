"""Contenido adicional y resúmenes calculados a partir de los artefactos originales."""

import csv
import json
from collections import Counter, defaultdict
from random import Random
from statistics import median, quantiles
from reportlab.graphics.shapes import Drawing, Line, Rect, String
from reportlab.lib import colors


def build(root, para, head, caption, table):
    def read(name):
        with (root / name).open(encoding="utf-8-sig", newline="") as source:
            return list(csv.DictReader(source))

    def number(value, decimals=3):
        return f"{value:.{decimals}f}".replace(".", ",")

    original = json.loads((root / "resultados.json").read_text(encoding="utf-8"))
    example = original["example"]
    folds = read("metricas_por_particion.csv")
    predictions = read("predicciones_fuera_de_muestra.csv")
    latency = read("latencias.csv")
    marginals = defaultdict(list)
    paired = defaultdict(list)
    seen = set()
    for row in latency:
        block = int(row["bloque"])
        key = block, row["perfil"]
        kind = "Repetida" if key in seen else "Primera"
        seen.add(key)
        base, cache = int(row["base_ns"]), int(row["cache_ns"])
        marginals[kind].append((base, cache))
        paired[block].append((base, cache))

    blocks = [median(base - cache for base, cache in values) / 1000
              for values in paired.values()]
    rng = Random(2026)
    draws = [median(rng.choices(blocks, k=len(blocks))) for _ in range(10000)]
    bounds = quantiles(draws, n=1000, method="inclusive")
    lo, hi = number(bounds[24]), number(bounds[974])
    transitions = Counter((row["prediction_baseline"] == row["label"],
                           row["prediction_nb"] == row["label"]) for row in predictions)
    classes = original["labels"]
    confusion = Counter((row["label"], row["prediction_nb"]) for row in predictions)
    class_rows = []
    for label in classes:
        support = sum(confusion[label, other] for other in classes)
        correct = confusion[label, label]
        class_rows.append((label, str(support), str(correct), number(100 * correct / support, 1)))

    def bars(values, maximum, unit):
        plot = Drawing(247, 132)
        plot.add(Line(79, 22, 79, 124, strokeWidth=.45))
        plot.add(Line(79, 22, 236, 22, strokeWidth=.45))
        for i, (label, base, alternative) in enumerate(values):
            y = 113 - 34 * i
            plot.add(String(1, y - 5, label, fontName="Article", fontSize=8))
            for lower, amount, shade in ((y, base, "#b1b1b1"), (y - 9, alternative, "#454545")):
                plot.add(Rect(79, lower, 156 * amount / maximum, 7,
                              fillColor=colors.HexColor(shade), strokeColor=None))
        plot.add(String(79, 10, "0", fontName="Article", fontSize=8))
        maximum_label = number(maximum, 2) if maximum < 1 else str(maximum)
        plot.add(String(236, 10, f"{maximum_label} {unit}",
                        textAnchor="end", fontName="Article", fontSize=8))
        return plot

    summary = original["summary"]
    r = json.loads((root / "rendimiento.json").read_text(encoding="utf-8"))
    comparison_plot = bars([
        (label, 100 * summary["Mayoritaria"][key]["mean"],
         100 * summary["Naive Bayes multinomial"][key]["mean"])
        for label, key in (("Exactitud", "accuracy"), ("Sensibilidad macro", "recall_macro"), ("F1 macro", "f1_macro"))
    ], 100, "%")
    latency_plot = bars([
        (label, r["base"][key], r["cache"][key])
        for label, key in (("Mediana", "mediana_ms"), ("p95", "p95_ms"), ("p99", "p99_ms"))
    ], .15, "ms")

    introduction = [
        head("A. Alcance del problema"),
        para("El proyecto de origen plantea una arquitectura de apoyo vocacional para estudiantes de secundaria de Andahuaylas. Su flujo prevé recopilar habilidades e intereses mediante un diálogo, producir una sugerencia y permitir que el estudiante pregunte por sus motivos. El presente experimento aísla el componente que convierte un texto de habilidades en una categoría. Al delimitar la etapa medida, la comparación puede repetirse con el mismo conjunto de solicitudes y el mismo clasificador."),
        para("En una interacción conversacional es posible que la persona vuelva a consultar un perfil que todavía no cambió. La repetición crea un caso de uso para reutilizar la tokenización. En cambio, una actualización del texto cambia la clave de caché y vuelve a calcular el conteo. La evaluación usa ambos casos dentro de un escenario controlado, con textos reservados del entrenamiento."),
        head("B. Objetivos específicos"),
        para("Primero, describir el desempeño predictivo con validación cruzada y una referencia de clase mayoritaria. Segundo, implementar dos rutas de inferencia que compartan el modelo y difieran en cómo obtienen los conteos. Tercero, estimar las latencias típicas y de cola, cuantificar el efecto pareado y comprobar la igualdad de las etiquetas en toda la carga."),
        caption("TABLA III<br/>OPERACIONALIZACIÓN DE VARIABLES"),
        table([
            ("Elemento", "Indicador y fuente"),
            ("Intervención", "Tokenización directa o caché LRU de 128 entradas"),
            ("Rendimiento", "Mediana, p95 y p99 de las duraciones registradas"),
            ("Concordancia", "Igualdad de la etiqueta dentro de cada par"),
            ("Clasificación", "Exactitud, F1 macro y sensibilidad por clase"),
            ("Controles", "Mismos textos, pesos, proceso, semilla y equipo"),
        ], [.33, .67]),
    ]
    review = [
        head("A. Extracción y criterios"),
        para("El corpus de partida fue la bibliografía del borrador del proyecto. Se incluyeron estudios primarios cuyo objeto fuera orientar o clasificar trayectorias educativas o profesionales y cuyo resumen describiera el enfoque evaluado. Se consultaron las fichas editoriales accesibles por DOI. De ellas se extrajeron la población o fuente de datos, la tarea, el método y la evidencia reportada. Mendeley Data se consultó por separado para documentar la procedencia de los datos."),
        para("El alcance de la revisión es deliberadamente acotado. Los tres trabajos permiten contrastar tipos de evidencia: respuestas de personas frente a un recomendador, métricas de clasificación acompañadas de explicaciones y predicción de aspiraciones a partir de encuestas. La selección dirigida permite fundamentar el diseño, aunque no permite estimar cuántos estudios sobre latencia existen en toda la literatura."),
        head("B. Comparabilidad de la evidencia"),
        para("Lahoud et al. [1] compararon enfoques de recomendación de áreas de estudio mediante un caso con escolares del Líbano. Su evaluación de utilidad percibida orienta la futura validación con estudiantes. La tarea depende de preferencias, conocimiento del dominio y alternativas formativas, mientras que el experimento local mide el costo de una llamada a un clasificador."),
        para("Guleria y Sood [2] compararon modelos supervisados en datos educativos e incorporaron técnicas de explicabilidad. Su estudio respalda observar métricas más allá de la exactitud. Faruque et al. [3] estudiaron la predicción de aspiraciones con encuestas a universitarios de computación e ingeniería de software. El depósito asociado [4] permite examinar el texto y las categorías que sustentan la replicación presentada."),
        para("De estos antecedentes se derivan dos decisiones. La prueba predictiva agrupa textos idénticos para evitar su cruce entre entrenamiento y evaluación. La prueba de rendimiento modifica solo la obtención de características para conservar la semántica del modelo. Ambas decisiones limitan la interpretación a preguntas que los artefactos disponibles permiten responder."),
    ]
    model = [
        head("A. Formulación del clasificador"),
        para("Para una clase c y un perfil x, la puntuación es la suma del logaritmo de la probabilidad previa de c y las contribuciones de los términos observados. Si x<sub>t</sub> es la frecuencia del término t, se utiliza la siguiente expresión."),
        para("s(c, x) = log P(c) + Σ<sub>t</sub> x<sub>t</sub> log P(t | c) &nbsp;&nbsp; (1)", 10, 14, 1),
        para("La probabilidad previa se estima por la proporción de registros de entrenamiento de cada clase. Para cada término del vocabulario, el suavizado añade uno al conteo y el denominador aumenta en el tamaño del vocabulario. Los términos ausentes del vocabulario de entrenamiento quedan fuera de la suma. La etiqueta se obtiene por la mayor puntuación."),
        para("Para explicar por qué la clase c supera a otra clase d, se resta su puntuación término por término. Las diferencias positivas favorecen a c y las negativas favorecen a d. La diferencia entre probabilidades previas también contribuye a la explicación. Esta descomposición describe el cálculo interno del modelo."),
        caption("TABLA IV<br/>RECONSTRUCCIÓN DEL EJEMPLO GUARDADO"),
        table([
            ("Componente", "Valor"),
            ("Diferencia de logaritmos de probabilidades previas", number(example["prior_difference"])),
            ("Suma de aportes de términos", number(example["contributions_sum"])),
            ("Margen de puntuación final", number(example["score_difference"])),
        ], [.72, .28]),
        para("La suma se comprobó con precisión numérica antes del redondeo. El registro explicativo corresponde al primer caso reservado de la primera partición, elegido por posición. El JSON conserva la clase observada, la predicción, la segunda clase y los aportes más altos y más bajos."),
    ]
    architecture = [
        head("A. Componentes y límites"),
        para("La capa de preparación construye cinco particiones a partir de textos normalizados y etiquetas. La capa de entrenamiento genera el vocabulario, los pesos y las probabilidades previas. La capa de inferencia recibe un texto y consulta el tokenizador directo o su variante con caché. El medidor rodea la llamada a inferencia y el registro escribe el resultado después de medir."),
        caption("TABLA V<br/>COMPONENTES DEL PROTOTIPO"),
        table([
            ("Componente", "Entrada y salida"),
            ("Preparación", "Encuestas públicas → textos, etiquetas y partición"),
            ("Entrenamiento", "Textos de entrenamiento → vocabulario y pesos"),
            ("Inferencia", "Texto reservado → clase con mayor puntuación"),
            ("Explicación", "Pesos y conteos → aportes a la diferencia entre dos clases"),
            ("Medición", "Llamadas pareadas → duraciones y orden de ejecución"),
        ], [.32, .68]),
        para("El código de clasificación original usa NumPy para calcular las puntuaciones de las particiones. El ensayo de rendimiento implementa las mismas operaciones del modelo con Python estándar y compara dos variantes de esa implementación dentro de un proceso. Por tanto, sus intervalos de tiempo describen el prototipo instrumentado."),
        para("En un despliegue posterior, un proceso iniciaría con una instancia de LRU propia. Un texto nuevo ocuparía una entrada y, al alcanzar la capacidad, la caché expulsaría la menos usada recientemente. Aquí los conteos son consumidos en lectura y la política de reinicio por bloque permite reproducir las condiciones de arranque."),
    ]
    protocol = [
        head("B. Preparación de datos y validación"),
        para("Se usó el archivo original depositado en Mendeley Data [4]. El código de clasificación comprueba su identidad mediante SHA-256. La normalización pasa el texto a minúsculas, elimina espacios sobrantes y conserva pares únicos de texto y etiqueta. Cuando un mismo texto aparece con dos etiquetas, ambas se conservan y se asignan juntas a la misma partición."),
        para("Se construyeron cinco particiones con tamaños de 418 o 419 registros. Cada vuelta reserva una partición y usa las cuatro restantes para construir vocabulario y entrenar. La referencia de clase mayoritaria se calcula con las etiquetas de entrenamiento. El procedimiento genera una predicción fuera de muestra para cada par depurado."),
        head("C. Carga y control experimental"),
        para("Cada bloque muestrea 128 textos distintos de la primera partición y mezcla dos copias de la lista. La segunda aparición de cada texto es un acierto de caché, porque el número de textos distintos del bloque coincide con su capacidad. La proporción prevista de aciertos es por tanto 50 %. La semilla permite repetir el mismo orden de perfiles y variantes."),
        para("El archivo crudo conserva el bloque, la posición, un identificador de perfil, qué ruta se ejecutó primero y ambos tiempos en nanosegundos. El par controla el efecto de la longitud y del vocabulario del perfil. El bloque agrupa las consultas que comparten el ciclo de vida de la caché y sirve de unidad de análisis estadístico."),
        para("La prueba se ejecutó sin concurrencia, dentro de un mismo proceso. El reloj se lee justo antes y después de puntuar y elegir la etiqueta. La carga de archivos, el entrenamiento y la escritura del CSV quedan fuera del intervalo. El criterio operativo se aplica al p95 absoluto y la hipótesis estadística a la diferencia pareada por bloques."),
    ]
    classification = [
        caption("TABLA VI<br/>EXACTITUD Y F1 MACRO POR PARTICIÓN"),
        table([
            ("Partición", "Exactitud base", "Exactitud NB", "F1 macro NB"),
            *[(str(index), number(100 * float(folds[i]["accuracy"]), 1) + " %",
               number(100 * float(folds[i + 1]["accuracy"]), 1) + " %",
               number(float(folds[i + 1]["f1_macro"])))
              for index, i in enumerate(range(0, len(folds), 2), 1)],
        ], [.23, .27, .25, .25]),
        para("La exactitud atribuye el mismo peso a cada registro. El F1 macro promedia el F1 de las clases con igual peso y se incluye debido al desbalance del corpus. La exactitud de Naive Bayes osciló entre 84,7 % y 89,7 %. Las cinco particiones favorecieron al clasificador frente a la regla mayoritaria."),
        para(f"En la comparación fuera de muestra, Naive Bayes acertó {transitions[False, True]} registros que la regla mayoritaria clasificó mal. En {transitions[True, False]} ocurrió lo contrario. Ambos acertaron {transitions[True, True]} y ambos se equivocaron en {transitions[False, False]}. Estos conteos ayudan a distinguir la ganancia neta de los cambios entre predicciones individuales."),
        comparison_plot,
        para("Fig. 1. Medias de validación cruzada. Gris claro, clase mayoritaria. Gris oscuro, Naive Bayes.", 8, 10, 0),
        caption("TABLA VII<br/>SENSIBILIDAD POR CLASE FUERA DE MUESTRA"),
        table([
            ("Clase", "Casos", "Aciertos", "%"),
            *class_rows,
        ], [.59, .13, .17, .11]),
        para("Las categorías de desarrollo se mantienen con los nombres del conjunto original. Sus límites semánticos pueden superponerse. Las tasas de la tabla describen esta taxonomía y el desempeño es sensible al soporte de cada clase. Una misma tasa en una clase pequeña y en una clase grande resume cantidades de evidencia diferentes."),
        head("B. Interpretación de la referencia"),
        para("La regla de clase mayoritaria es una referencia de bajo costo para el desbalance. Su sensibilidad macro es 1/6 porque asigna todos los casos a una sola clase. Superarla demuestra que las características del perfil contienen señal aprovechable para esta tarea. Una comparación contra otros clasificadores requeriría entrenarlos con las mismas particiones y definir sus parámetros con datos de entrenamiento."),
        para("Las métricas por partición describen estabilidad ante las divisiones realizadas. Debido a que los conjuntos de entrenamiento se superponen, las cinco métricas no representan cinco estudios independientes y se presentan como resultados descriptivos."),
    ]
    performance = [
        caption("TABLA VIII<br/>MEDIANA POR TIPO DE CONSULTA EN MICROSEGUNDOS"),
        table([
            ("Consulta", "Pares", "Base", "Caché", "Delta"),
            *[(kind, str(len(values)), number(median(a for a, _ in values) / 1000, 1),
               number(median(b for _, b in values) / 1000, 1),
               number(median(a - b for a, b in values) / 1000, 1))
              for kind, values in marginals.items()],
        ], [.22, .17, .20, .20, .21]),
        para("La tabla separa el primer acceso a cada perfil de su repetición. En el primer acceso, ambas variantes tokenizan y la variante LRU realiza además la consulta e inserción. En el segundo acceso, la variante LRU reutiliza el conteo. La mediana de los deltas se calcula sobre pares y puede diferir de la resta de las medianas marginales."),
        para(f"Como análisis complementario se remuestrearon los 40 bloques con reemplazo en 10 000 réplicas, usando semilla 2026. El intervalo percentil descriptivo del 95 % para la mediana de los deltas fue [{lo}; {hi}] µs. El remuestreo cuantifica la dispersión de los bloques observados en esta sesión y comparte el supuesto de independencia de la prueba de signos."),
        para("La mediana caracteriza una llamada típica. El p95 y el p99 muestran cuánto tardan las llamadas de cola, que pueden ser más sensibles a interrupciones del sistema. El efecto estadístico se estima mediante los deltas pareados por bloque. El objetivo operativo de p95 se interpreta sobre los tiempos absolutos de cada variante."),
        head("A. Auditoría de las métricas"),
        para("Las duraciones en nanosegundos se dividen por un millón para pasar a milisegundos. Los percentiles se calculan sobre los tiempos individuales de cada brazo. Para reproducir la prueba de signos se calcula un delta mediano por bloque y se cuenta cuántas veces es positivo o negativo. En caso de empate, el bloque queda fuera del recuento de signos."),
        latency_plot,
        para("Fig. 2. Latencia por percentil. Gris claro, tokenización directa. Gris oscuro, caché LRU.", 8, 10, 0),
    ]
    validity = [
        head("A. Validez interna"),
        para("El orden aleatorio de las variantes reduce el sesgo de ejecutar siempre la misma ruta primero. Dentro de cada par, el mismo perfil determina la longitud del texto y el número de términos. El reinicio de la caché evita arrastrar perfiles entre bloques. Durante la sesión todavía pueden influir el planificador del sistema, el calentamiento de la CPU y la memoria del intérprete."),
        head("B. Validez de constructo"),
        para("Se midió el tiempo de una función que retorna una clase. La latencia percibida por un usuario incluiría validación de entrada, serialización, red y presentación de la respuesta. El criterio de concordancia comprueba igualdad técnica entre rutas. La pertinencia de la orientación requeriría un criterio de referencia educativo y evaluación con personas."),
        head("C. Validez externa y estadística"),
        para("La carga de 50 % de repeticiones fue diseñada para aislar el mecanismo de reutilización. Una tasa distinta, solicitudes concurrentes o un despliegue con varios procesos pueden modificar el beneficio observado. El resultado inferencial se condiciona a bloques de una sola sesión. Sesiones independientes permitirían evaluar la variación entre ejecuciones y equipos."),
        para("En clasificación, agrupar por texto exacto evita ese tipo de solapamiento. Los textos parafraseados pueden conservar información similar. Como el conjunto carece de un identificador de participante en el archivo usado, no se pudo verificar la independencia por persona. La distribución de habilidades y aspiraciones de los universitarios encuestados acota la transferencia a otro contexto."),
    ]
    discussion = [
        head("A. Implicaciones para el diseño"),
        para("La puntuación domina parte del costo que permanece después de recuperar los conteos. La optimización actúa en una etapa delimitada y el ahorro se aprecia especialmente en consultas que repiten el texto. Si el usuario modifica su perfil, la clave cambia. Por ello, el beneficio productivo depende de cuántas solicitudes vuelvan al mismo texto dentro de la ventana efectiva de la caché."),
        para("El presupuesto de 1 ms se fijó para inferencia local. Los resultados colocaron las dos variantes por debajo de ese límite y respaldan una decisión operativa basada también en memoria y complejidad. Ante una tasa reducida de repeticiones, el beneficio podría disminuir. Los percentiles de un servicio desplegado se deben obtener con su carga y configuración reales."),
        head("B. Interpretación educativa"),
        para("Una categoría predicha resume patrones entre habilidades y aspiraciones del corpus. La explicación indica qué vocabulario dio ventaja a una categoría frente a otra. Para usar ambos elementos como parte de un chatbot, la interfaz debería presentar la categoría como una posibilidad e invitar al estudiante a considerar otras opciones. Una prueba de comprensión podría pedirle identificar qué parte de su perfil influyó en la respuesta."),
        para("La validación futura separaría la concordancia con un criterio experto, la comprensión y el rendimiento técnico de extremo a extremo. El tamaño de muestra, el umbral y el protocolo de evaluación deberían definirse para esa población y ese servicio antes de ejecutar la prueba correspondiente."),
    ]
    return introduction, review, model, architecture, protocol, classification, performance, validity, discussion
