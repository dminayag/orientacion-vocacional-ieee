"""Compone el artículo IEEE en dos columnas."""

import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, Table, TableStyle
from ampliacion import build

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "Articulo_IEEE_Orientacion_Vocacional.pdf"
R = json.loads((ROOT / "rendimiento.json").read_text(encoding="utf-8"))
W, H = 612, 792
MARGIN, GAP = 45, 18
COL = (W - 2 * MARGIN - GAP) / 2
pdf = canvas.Canvas(str(OUT), pagesize=(W, H))
pdf.setTitle("Evaluación de un clasificador explicable de aspiraciones profesionales")
pdf.setAuthor("Daniel Minaya Gutiérrez")
fonts = Path("C:/Windows/Fonts")
for name, file in (("Article", "times.ttf"), ("ArticleBold", "timesbd.ttf"),
                   ("ArticleItalic", "timesi.ttf"), ("ArticleBoldItalic", "timesbi.ttf")):
    pdfmetrics.registerFont(TTFont(name, str(fonts / file)))
pdfmetrics.registerFontFamily("Article", normal="Article", bold="ArticleBold",
                              italic="ArticleItalic", boldItalic="ArticleBoldItalic")


def para(text, size=10, leading=12, align=4, font="Article"):
    return Paragraph(text, ParagraphStyle(
        "article", fontName=font, fontSize=size, leading=leading, alignment=align
    ))


def head(text):
    return para(text.upper(), 10, 13, 1)


def caption(text):
    labels = {"I": "II", "II": "VII", "III": "I", "IV": "III", "V": "IV",
              "VI": "V", "VII": "VI", "VIII": "VIII"}
    name, content = text.split("<br/>", 1)
    text = f"TABLA {labels[name.split()[-1]]}<br/>{content}"
    return para(text, 8, 10, 1)


def table(rows, widths):
    cells = [[para(value, 8, 10, 0) for value in row] for row in rows]
    result = Table(cells, colWidths=[COL * width for width in widths])
    result.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LINEABOVE", (0, 0), (-1, 0), .6, colors.black),
        ("LINEBELOW", (0, 0), (-1, 0), .35, colors.black),
        ("LINEBELOW", (0, -1), (-1, -1), .6, colors.black),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    return result


def draw(items, x, top, width=COL):
    for item in items:
        _, height = item.wrap(width, top)
        top -= height
        if top < 50:
            raise ValueError(f"Columna fuera del margen inferior en página {pdf.getPageNumber()}")
        item.drawOn(pdf, x, top)
        top -= 7


def footer(page):
    pdf.setFont("Times-Roman", 9)
    pdf.drawCentredString(W / 2, 32, str(page))


def link(url, label):
    return f'<link href="{url}" color="#184974">{label}</link>'


def ms(value):
    return f"{value:.4f}".replace(".", ",")


count = f"{R['pares']:,}".replace(",", " ")
left = [
    para(f"<b><i>Resumen</i>—</b> Se evaluó un clasificador explicable de aspiraciones profesionales y se midió el efecto de reutilizar la tokenización de perfiles repetidos. Sobre 2 093 registros públicos depurados, Naive Bayes multinomial alcanzó 87,1 % de exactitud media en cinco particiones frente a 26,6 % de la clase mayoritaria. En {count} pares de inferencias locales, el percentil 95 bajó de {ms(R['base']['p95_ms'])} a {ms(R['cache']['p95_ms'])} ms con caché. Las dos variantes devolvieron la misma clase en todos los pares. Los resultados cubren la clasificación y la latencia del componente local.",
         9, 11),
    para("<b><i>Palabras clave</i>—</b> orientación vocacional, Naive Bayes, explicabilidad, caché LRU, latencia.", 9, 11),
    head("I. Introducción"),
    para("Un sistema de orientación vocacional puede clasificar habilidades declaradas y explicar qué términos influyen en la categoría sugerida. Si un perfil se consulta varias veces, el servicio vuelve a tokenizar el mismo texto. El problema técnico es determinar cuánto trabajo se evita al conservar las características del perfil en memoria."),
    para("<i>Pregunta y objetivo.</i> ¿En qué medida una caché LRU de tokenización reduce la latencia local conservando las predicciones? Se busca comparar ambas variantes del clasificador y estimar el efecto de la intervención."),
    para("<i>Hipótesis y umbral.</i> H₀: la probabilidad de que un bloque favorezca a la caché es como máximo 0,5. H₁: es mayor que 0,5. Se fijó α = 0,05 y un presupuesto técnico local de p95 ≤ 1 ms antes de ejecutar la prueba. La variable independiente es el uso de caché. Las dependientes son la latencia y la concordancia de las predicciones. Se mantienen fijos el modelo, los perfiles comparados y el entorno."),
    head("II. Estado del arte"),
    para("Se seleccionaron del borrador del proyecto tres estudios primarios sobre recomendación académica, clasificación explicable y predicción de aspiraciones. Se verificaron por DOI en la editorial y se extrajeron enfoque y alcance. La revisión es dirigida y la matriz resume los estudios incluidos."),
]

right = [
    caption("TABLA I<br/>MATRIZ DE ESTUDIOS RELACIONADOS"),
    table([
        ("Estudio", "Enfoque", "Alcance evaluado"),
        ("Lahoud et al. [1]", "Recomendación híbrida", "Escolares del Líbano"),
        ("Guleria y Sood [2]", "Clasificadores y XAI", "Datos educativos y empleabilidad"),
        ("Faruque et al. [3]", "Predicción y XAI", "Encuesta universitaria"),
    ], [.29, .34, .37]),
    para("<i>Brecha.</i> Estos antecedentes motivan la clasificación explicable. Aquí se aísla el costo de tokenizar perfiles repetidos y se comprueba que su reutilización conserva la salida del modelo."),
    head("III. Propuesta"),
    para("El flujo conceptual es perfil normalizado → conteo de términos → puntuación por clase → etiqueta y contribuciones. La caché guarda los conteos por texto exacto y admite 128 entradas. Una diferencia de puntuación entre la clase ganadora y la segunda se explica sumando el aporte de cada término y la diferencia de los logaritmos de las probabilidades previas."),
    para("<i>Trazabilidad.</i> La hipótesis de rendimiento se contrasta con las latencias pareadas del CSV. La preservación del comportamiento se verifica por igualdad de etiquetas en cada par. Las predicciones fuera de muestra sustentan las métricas de clasificación y el JSON original conserva un ejemplo de reconstrucción de la explicación."),
    head("IV. Arquitectura y experimento"),
    para("El prototipo se ejecutó en un proceso Python 3.12.14, en Windows 11 sobre AMD64. Se entrenó Naive Bayes multinomial con suavizado de Laplace y las particiones 2 a 5 del conjunto público [4]. Se reservaron para la carga los textos de la partición 1. Ambas variantes comparten pesos y rutina de puntuación. La línea base tokeniza en cada llamada y la otra utiliza una caché en memoria."),
    para("Se ejecutaron 40 bloques. Cada bloque comienza con caché vacía y contiene 128 perfiles distintos, cada uno consultado dos veces en orden aleatorio. Se aleatorizó el orden de ejecución de las variantes por par. El reloj monotónico de alta resolución midió desde la entrada a inferencia hasta la obtención de la etiqueta. El script registra la duración de ambos brazos en nanosegundos."),
]


effect_us = f"{R['efecto_mediana_delta_ms'] * 1000:.3f}".replace(".", ",")
mantissa, exponent = f"{R['p_signos_unilateral']:.2e}".split("e")
p_text = f"{mantissa.replace('.', ',')} × 10<super>{int(exponent)}</super>"


page2_left = [
    head("V. Evaluación experimental"),
    para("<i>Clasificación.</i> De 4 076 registros originales se eliminaron 1 983 pares duplicados de texto y etiqueta. La validación agrupó los textos idénticos en la misma partición. La exactitud media fue 87,1 % para Naive Bayes y 26,6 % para la clase mayoritaria. El F1 macro medio fue 0,886 y 0,070, respectivamente. Las etiquetas corresponden a aspiraciones autodeclaradas."),
    para("<i>Rendimiento.</i> La Tabla VII presenta los percentiles de las llamadas medidas, calculados por interpolación lineal. La igualdad de las etiquetas se verificó en todos los pares. Ambas variantes cumplieron el presupuesto local de p95."),
    caption("TABLA II<br/>LATENCIA LOCAL DE INFERENCIA EN MILISEGUNDOS"),
    table([
        ("Variante", "Mediana", "p95", "p99"),
        *[(name, *(ms(R[key][metric]) for metric in ("mediana_ms", "p95_ms", "p99_ms")))
          for name, key in (("Sin caché", "base"), ("Con caché", "cache"))],
    ], [.34, .22, .22, .22]),
    para(f"<i>Inferencia estadística.</i> La unidad de análisis fue el bloque. Se calculó la mediana de las diferencias pareadas base menos caché en cada bloque. La prueba exacta unilateral de signos favoreció la caché en {R['bloques_favorables']} de {R['bloques']} bloques (p = {p_text}). El tamaño del efecto en la escala original, medido como la mediana de esas diferencias por bloque, fue {effect_us} µs."),
    head("VI. Amenazas a la validez"),
    para("Los bloques se midieron en una sola sesión y pueden compartir fluctuaciones del equipo. La prueba de signos supone independencia entre bloques. La repetición de perfiles se fijó por diseño, y la carga, el grado de concurrencia y el tamaño de la caché pueden cambiar el efecto. Las encuestas proceden de universitarios de Bangladesh. La transferencia a escolares de Andahuaylas requiere evidencia propia."),
]

page2_right = [
    head("VII. Discusión"),
    para("La caché evita la tokenización en la mitad de las consultas de esta carga. El ahorro local es pequeño en términos absolutos. Como las dos variantes ya satisfacen el presupuesto de 1 ms, el resultado justifica medir escenarios con distintas tasas de repetición antes de incorporar caché a un servicio. La medición excluye la red, la generación de explicaciones y la interfaz conversacional."),
    head("VIII. Conclusiones y trabajo futuro"),
    para("La reutilización de conteos redujo la latencia local del clasificador para la carga repetida y conservó las etiquetas. La validación cruzada respalda el uso de Naive Bayes como línea de trabajo para clasificar aspiraciones en el conjunto estudiado. Queda por medir la latencia de un servicio desplegado y evaluar la comprensión de las explicaciones con la población destinataria."),
    head("Disponibilidad de código y datos"),
    para("El repositorio público contiene el código, la configuración Docker, los datos y las mediciones originales. "
         + link("https://github.com/dminayag/orientacion-vocacional-ieee",
                "github.com/dminayag/orientacion-vocacional-ieee")
         + ". El conjunto de origen está disponible en Mendeley Data [4]."),
    head("Referencias"),
]
references = [
    ("C. Lahoud et al., “A comparative analysis of different recommender systems for university major and career domain guidance,” <i>Educ. Inf. Technol.</i>, vol. 28, pp. 8733–8759, 2023.", "10.1007/s10639-022-11541-3"),
    ("P. Guleria y M. Sood, “Explainable AI and machine learning: performance evaluation and explainability of classifiers on educational data mining inspired career counseling,” <i>Educ. Inf. Technol.</i>, vol. 28, pp. 1081–1116, 2023.", "10.1007/s10639-022-11221-2"),
    ("S. H. Faruque, S. A. Khushbu y S. Akter, “Decision support system to reveal future career over students’ survey using explainable AI,” <i>Educ. Inf. Technol.</i>, vol. 30, pp. 14471–14509, 2025.", "10.1007/s10639-025-13361-7"),
    ("S. H. Faruque y S. A. Khushbu, <i>Student Career Dataset</i>, Mendeley Data, versión 2, 2024.", "10.17632/4spj4mbpjr.2"),
]
for number, (reference, doi) in enumerate(references, 1):
    page2_right.append(para(f"[{number}] {reference} {link('https://doi.org/' + doi, doi)}.", 8, 10, 0))

intro, review, model, architecture, protocol, classification, performance, validity, discussion = build(
    ROOT, para, head, caption, table
)
future = [
    head("A. Reproducción y extensión del estudio"),
    para("El ZIP conserva las dos rutas de análisis. El script de clasificación parte del archivo original de Mendeley, genera las particiones y produce un CSV con las predicciones de los dos modelos. El script de rendimiento usa las particiones exportadas, entrena con cuatro de ellas y produce las duraciones pareadas. Se conservan también los JSON de resultados y el código de composición del artículo."),
    para("Para verificar la trazabilidad, las métricas de clasificación se reconstruyen a partir de las columnas de etiqueta y predicción del CSV. Las tablas de rendimiento se reconstruyen a partir de las columnas de duración. El identificador de perfil permite distinguir el primer acceso de la repetición dentro de cada bloque. Los archivos originales se deben conservar si se realiza una nueva corrida, porque el script escribe resultados nuevos."),
    para("La configuración Docker permite preparar un entorno de réplica con Python 3.12.14. Las cifras del presente artículo se obtuvieron en Windows. Una réplica en contenedor deberá registrar el entorno y sus propios tiempos, y puede comparar la dirección y la magnitud del efecto con la corrida incluida."),
    head("B. Siguiente experimento"),
    para("Una réplica de rendimiento puede cruzar tasas de repetición y concurrencia, alternar configuraciones en múltiples sesiones e instrumentar el consumo de memoria. El ensayo debería registrar la tasa real de aciertos de caché y distinguir la latencia dentro del proceso de la latencia vista por el cliente."),
    para("Una validación educativa separada puede comprobar si el usuario entiende la justificación y si esa información le ayuda a explorar opciones. Para ello se necesitan respuestas de la población destinataria y una referencia educativa definida antes de la evaluación. La comparación de latencia de este artículo proporciona una base técnica para diseñar la instrumentación."),
]
draw([
    para("Evaluación de un clasificador explicable de<br/>aspiraciones profesionales con caché de tokenización",
         21, 24, 1),
    para("Daniel Minaya Gutiérrez<br/><i>Universidad Nacional José María Arguedas</i><br/>Andahuaylas, Perú", 11, 14, 1),
], MARGIN, 749, W - 2 * MARGIN)
pages = [
    (left[:-2], intro),
    (left[-2:] + review, right[:3] + right[3:4] + model),
    (right[4:7] + architecture, right[7:] + protocol),
    (page2_left[:2] + classification[:6], classification[6:]),
    (page2_left[2:6] + performance[-2:], performance[:-2]),
    (page2_left[6:] + validity, page2_right[:2] + discussion),
    (page2_right[2:4] + future[:4], future[4:] + page2_right[4:]),
]
for page, (first, second) in enumerate(pages, 1):
    top = 635 if page == 1 else 746
    draw(first, MARGIN, top)
    draw(second, MARGIN + COL + GAP, top)
    footer(page)
    if page < len(pages):
        pdf.showPage()
pdf.save()
